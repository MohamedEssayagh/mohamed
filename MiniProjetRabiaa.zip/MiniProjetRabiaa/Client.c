#ifndef CLIENT
#define CLIENT
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define ClientFile "Client.txt"

typedef struct Client{
 int idClient;
 char nom[20];
 char prenom[20];
 int cin;
 char adresse[15];
 int telephone;
}Client;

typedef struct ListClient{
    Client client;
    struct ListClient* suivant;
}ListClient;

int ajoutClientList(Client client,  ListClient** list){
    ListClient* tmp=NULL;
    tmp=(ListClient*)malloc(sizeof(ListClient));
    if(tmp==NULL)
        return 0;
    tmp->client.idClient=client.idClient;
    tmp->client.cin=client.cin;
    strcpy(tmp->client.nom, client.nom);
    strcpy(tmp->client.prenom, client.prenom);
    strcpy(tmp->client.adresse, client.adresse);
    tmp->client.telephone=client.telephone;
    tmp->suivant=NULL;
    /*La liste est vide*/
    if(!(*list))
        *list=tmp;
    else{//ajouter en tete de la liste
        tmp->suivant=*list;
        *list=tmp;
    }
    return 1;
}


/*du fichier vers un liste*/
void init_client(){

}

int list_client(){

}
#endif
