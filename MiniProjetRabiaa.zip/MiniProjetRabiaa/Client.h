#ifndef CLIENT_H_INCLUDED
#define CLIENT_H_INCLUDED
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define ClientFile "Client.txt"



typedef struct Client{
 int idClient;
 char nom[20];
 char prenom[20];
 int cine;
 char adresse[30];
 char telephone[15];
}Client;

typedef struct ListClient{
    Client client;
    struct ListClient* suivant;
}ListClient;

typedef struct ArbreCLient{
    Client client;
    struct ArbreCLient* right;
    struct ArbreCLient* left;
}ArbreCLient;

int inserClientArbre(ArbreCLient** arbClient, Client client){
    if((*arbClient)==NULL){
        *arbClient=(ArbreCLient*)malloc(sizeof(ArbreCLient));
        if(*arbClient==NULL)
            exit(0);
        (*arbClient)->left=NULL;
        (*arbClient)->right=NULL;
        (*arbClient)->client.cine=client.cine;
        (*arbClient)->client.idClient=client.idClient;
        strcpy((*arbClient)->client.adresse, client.adresse);
        strcpy((*arbClient)->client.nom, client.nom);
        strcpy((*arbClient)->client.telephone, client.telephone);
        strcpy((*arbClient)->client.prenom, client.prenom);
        return 1;
    }else if((*arbClient)->client.idClient<client.idClient)
            inserClientArbre(&((*arbClient)->right), client);
        else inserClientArbre(&((*arbClient)->left), client);
}

void afficheClientArbre(ArbreCLient* arbClient, FILE* fclient){
    if(arbClient!=NULL){
        afficheClientArbre(arbClient->left, fclient);
        fprintf(fclient,"%d\n",arbClient->client.idClient);
        fprintf(fclient,"%d\n",arbClient->client.cine);
        fprintf(fclient,"%s\n",arbClient->client.nom);//fputs(liste_total_client->client.nom,fclient);
        fprintf(fclient,"%s\n",arbClient->client.prenom);//fputs(liste_total_client->client.prenom,fclient);
        fprintf(fclient,"%s\n",arbClient->client.adresse);//fputs(liste_total_client->client.adresse,fclient);
        fprintf(fclient,"%s\n",arbClient->client.telephone);//fputs(liste_total_client->client.telephone,fclient);
        afficheClientArbre(arbClient->right, fclient);
    }
}

void chomp_(char *s)
{
    while (*s != '\n' && *s != '\0')
        ++s;
    *s = '\0';
}

int ajout_Client_List(Client client,  ListClient** liste){
    ListClient* tmp=NULL;
    tmp=(ListClient*)malloc(sizeof(ListClient));
    if(tmp==NULL)
        return 0;
    tmp->client.idClient=client.idClient;
    tmp->client.cine=client.cine;
    strcpy(tmp->client.nom, client.nom);
    strcpy(tmp->client.prenom, client.prenom);
    strcpy(tmp->client.adresse, client.adresse);
    strcpy(tmp->client.telephone,client.telephone);
    tmp->suivant=NULL;
    /*La liste est vide*/
    if(!(*liste))
        *liste=tmp;
    else{//ajouter en tete de la liste
        ListClient* tmp1=*liste;
        while(tmp1->suivant)
            tmp1=tmp1->suivant;
        tmp1->suivant=tmp;
    }
    return 1;
}

char* affiche_client(Client client, char* tmp, int i){
    sprintf(tmp, "Client %d) Identifier du client: %d  Nom du client: %s %s CIN: %d Telephone: %s\n\n",i, client.idClient, client.nom, client.prenom, client.cine, client.telephone);
    return tmp;
}

char* affiche_client_contrat(Client client, char* tmp){
    sprintf(tmp, "Client: Nom : %s %s  Telephone: %s  CIN: %d\n", client.nom, client.prenom, client.telephone, client.cine);
    return tmp;
}


int affiche_list_client(ListClient* liste, char* infoClients){
    if(!liste)
        return 0;
        int i=1;
    while(liste){
            char strTotal[10000];
            affiche_client(liste->client, strTotal, i++);
            strcat(infoClients, strTotal);
            liste=liste->suivant;
    }
    return 1;
}


Client* trouverClientId(ListClient* liste_total_client, int idClient){
    while(liste_total_client){
        if(liste_total_client->client.idClient==idClient)
            return &liste_total_client->client;
        liste_total_client=liste_total_client->suivant;
    }
    return NULL;
}

int trouveClientParNom(ListClient* liste_total_client, char* nom, char* prenom){
    while(liste_total_client){
        if(!strcmp(liste_total_client->client.nom, nom) && !strcmp(liste_total_client->client.prenom,prenom))
            return liste_total_client->client.idClient;
        liste_total_client=liste_total_client->suivant;
    }
    return 0;
}

int supprimer_Client_List(int idClient, ListClient** liste){
    int trouve=0;
    if(!(*liste))
        return 0;
    ListClient* tmp=*liste;
    if((*liste)->client.idClient==idClient){
        *liste=(*liste)->suivant;
        free(tmp);
        return 1;
    }
    while(tmp->suivant){
        if(tmp->suivant->client.idClient!=idClient)
            tmp=tmp->suivant;
        else {
            trouve=1;
            break;
        }
    }
    if(trouve==1){
        tmp->suivant=tmp->suivant->suivant;
        free(tmp->suivant);
        return 1;
    }
    return 0;
}

int modef_Client_List(ListClient** liste, int IdClient, char* nom, char* prenom, int cine, char* adresse, char* telephone){
    int trouve=0;
    ListClient* tmp=*liste;
    while(tmp){
        if(tmp->client.idClient==IdClient){
            trouve=1;
            break;
        }
        tmp=tmp->suivant;
    }
    if(trouve==0)
        return 0;
    tmp->client.cine=cine;
    strcpy(tmp->client.nom, nom);
    strcpy(tmp->client.prenom, prenom);
    strcpy(tmp->client.adresse, adresse);
    strcpy(tmp->client.telephone,telephone);
    return 1;
}

/*du fichier vers un liste*/
void init_client(ListClient** liste_total_client){
    char data[30];
    Client client;
    FILE *fclient=NULL;
    fclient = fopen(ClientFile ,"r");
    if(fclient==NULL){
       // printf("le fichier n'existe pas, on va cr�er un pour vous\n");
        fclient = fopen(ClientFile ,"w");
        fclose(fclient);
        fclient = fopen(ClientFile ,"r");
    }
    while(fgets(data,30,fclient)){//fgets(data,30,fclient) fscanf(fclient,"%d\n",data)
        //printf("ici 2");
        client.idClient=atoi(data);

        //fscanf(fclient,"%d\n",data);
        fgets(data,30,fclient);
        client.cine=atoi(data);

        //fscanf(fclient,"%s",data);
        fgets(data,30,fclient);
        chomp_(data);
        strcpy(client.nom, data);

        //fscanf(fclient,"%s",data);
        fgets(data,30,fclient);
        chomp_(data);
        strcpy(client.prenom, data);

        //fscanf(fclient,"%s",data);
        fgets(data,30,fclient);
        chomp_(data);
        strcpy(client.adresse, data);

        //fscanf(fclient,"%s",data);
        fgets(data,30,fclient);
        chomp_(data);
        strcpy(client.telephone,data);

        ajout_Client_List(client, liste_total_client);
    }
    fclose(fclient);
}

void exit_client(ListClient* liste_total_client, void (*afficheClientArbre)(ArbreCLient*, FILE *)){
    FILE *fclient=NULL;
    fclient = fopen(ClientFile ,"w");
    ArbreCLient* arbClient=NULL;
    while(liste_total_client){
        inserClientArbre(&arbClient, liste_total_client->client);
        liste_total_client=liste_total_client->suivant;
    }
    (*afficheClientArbre)(arbClient, fclient);
    fclose(fclient);
}

#endif

