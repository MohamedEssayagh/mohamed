#ifndef VOITURE_H_INCLUDED
#define VOITURE_H_INCLUDED
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define VoitureFile "Voiture.txt"

typedef struct Voiture{
 int idVoiture;
 char marque[15];
 char nomVoiture[15];
 char couleur[7];
 int nbplaces;
 int prixJour;
 char EnLocation[4];
} Voiture;

typedef struct ListVoiture{
    Voiture voiture;
    struct ListVoiture* suivant;
}ListVoiture;

typedef struct ArbreVoiture{
    Voiture voiture;
    struct ArbreVoiture* right;
    struct ArbreVoiture* left;
}ArbreVoiture;

int inserVoitureArbre(ArbreVoiture** arbVoiture, Voiture voiture){
    if((*arbVoiture)==NULL){
        *arbVoiture=(ArbreVoiture*)malloc(sizeof(ArbreVoiture));
        if(*arbVoiture==NULL)
            exit(0);
        (*arbVoiture)->left=NULL;
        (*arbVoiture)->right=NULL;
        (*arbVoiture)->voiture.idVoiture=voiture.idVoiture;
        (*arbVoiture)->voiture.nbplaces=voiture.nbplaces;
        (*arbVoiture)->voiture.prixJour=voiture.prixJour;
        strcpy((*arbVoiture)->voiture.couleur, voiture.couleur);
        strcpy((*arbVoiture)->voiture.EnLocation, voiture.EnLocation);
        strcpy((*arbVoiture)->voiture.marque, voiture.marque);
        strcpy((*arbVoiture)->voiture.nomVoiture, voiture.nomVoiture);
        return 1;
    }else if((*arbVoiture)->voiture.idVoiture<voiture.idVoiture)
            inserVoitureArbre(&((*arbVoiture)->right), voiture);
        else inserVoitureArbre(&((*arbVoiture)->left), voiture);
}

void afficheVoitureArbre(ArbreVoiture* arbVoiture, FILE* fvoiture){
    if(arbVoiture!=NULL){
        afficheVoitureArbre(arbVoiture->left, fvoiture);
        fprintf(fvoiture,"%d\n",arbVoiture->voiture.idVoiture);
        fprintf(fvoiture,"%s\n",arbVoiture->voiture.marque); //fputs(liste_total_voiture->voiture.marque, fvoiture);
        fprintf(fvoiture,"%s\n",arbVoiture->voiture.nomVoiture); //fputs(liste_total_voiture->voiture.nomVoiture, fvoiture);
        fprintf(fvoiture,"%s\n",arbVoiture->voiture.couleur);//fputs(liste_total_voiture->voiture.couleur, fvoiture);
        fprintf(fvoiture,"%d\n",arbVoiture->voiture.nbplaces);
        fprintf(fvoiture,"%d\n",arbVoiture->voiture.prixJour);
        fprintf(fvoiture,"%s\n",arbVoiture->voiture.EnLocation);//fputs(liste_total_voiture->voiture.EnLocation, fvoiture);
        afficheVoitureArbre(arbVoiture->right, fvoiture);
    }
}

void chomp(char *s)
{
    while (*s != '\n' && *s != '\0')
        ++s;
    *s = '\0';
}

char* affiche_voiture(Voiture voiture, char* tmp, int i){
    sprintf(tmp, "Voiture %d) Id Voiture: %d Marque: %s Nom de Voiture: %s Couleur: %s Nobmre de Place: %d Prix par journee: %dDhs En Location: %s\n\n",i, voiture.idVoiture, voiture.marque, voiture.nomVoiture, voiture.couleur, voiture.nbplaces, voiture.prixJour, voiture.EnLocation);
    return tmp;
}

char* affiche_voiture_contrat(Voiture voiture, char* tmp){
    sprintf(tmp, "Voiture: Id: %d Marque: %s %s\n", voiture.idVoiture, voiture.marque, voiture.nomVoiture);
    return tmp;
}

int affiche_list_voiture(ListVoiture* liste, char* infoVoiture){
    if(!liste)
        return 0;
        int i=1;
    while(liste){
            char strTotal[10000];
            affiche_voiture(liste->voiture, strTotal, i++);
            strcat(infoVoiture, strTotal);
            liste=liste->suivant;
    }
    return 1;
}

Voiture* trovuerVoitureId(ListVoiture* lisute_total_voiture, int idVoiture){
    while(lisute_total_voiture){
        if(lisute_total_voiture->voiture.idVoiture==idVoiture)
            return &lisute_total_voiture->voiture;
        lisute_total_voiture=lisute_total_voiture->suivant;
    }
    return NULL;
}

int trouveVoitureNom(ListVoiture* lisute_total_voiture, char* marque, char* nomVoiture, char* couleur, int nbplaces){
    int counts=0;
    //printf("%d\n",strcmp(lisute_total_voiture->voiture.marque, marque));
    while(lisute_total_voiture){
        if(!strcmp(lisute_total_voiture->voiture.marque, marque) && !strcasecmp(lisute_total_voiture->voiture.nomVoiture, nomVoiture)
           && !strcmp(lisute_total_voiture->voiture.couleur, couleur) && lisute_total_voiture->voiture.nbplaces==nbplaces)
            counts++;
        lisute_total_voiture=lisute_total_voiture->suivant;
    }
    return counts;
}

int trouveVoitureNomID(ListVoiture* lisute_total_voiture, char* marque, char* nomVoiture, char* couleur, int nbplaces){
    while(lisute_total_voiture){
        if(!strcmp(lisute_total_voiture->voiture.marque, marque) && !strcasecmp(lisute_total_voiture->voiture.nomVoiture, nomVoiture)
           && !strcmp(lisute_total_voiture->voiture.couleur, couleur) && lisute_total_voiture->voiture.nbplaces==nbplaces && !strcmp(lisute_total_voiture->voiture.EnLocation, "Non"))
            return lisute_total_voiture->voiture.idVoiture;
        lisute_total_voiture=lisute_total_voiture->suivant;
    }
    return 0;
}

int ajout_Voiture_List(Voiture voiture ,  ListVoiture** liste){
    ListVoiture* tmp=NULL;
    tmp=(ListVoiture*)malloc(sizeof(ListVoiture));
    if(tmp==NULL)
        return 0;
    tmp->voiture.idVoiture=voiture.idVoiture;
    tmp->voiture.nbplaces=voiture.nbplaces;
    tmp->voiture.prixJour=voiture.prixJour;
    strcpy(tmp->voiture.couleur,voiture.couleur);
    strcpy(tmp->voiture.EnLocation,voiture.EnLocation);
    strcpy(tmp->voiture.marque,voiture.marque);
    strcpy(tmp->voiture.nomVoiture,voiture.nomVoiture);
    tmp->suivant=NULL;
    /*La liste est vide*/
    if(!(*liste))
        *liste=tmp;
    else{//ajouter en tete de la liste
        ListVoiture* tmp1=*liste;
        while(tmp1->suivant)
            tmp1=tmp1->suivant;
        tmp1->suivant=tmp;
    }
    return 1;
}

int supprimer_Voiture_List(int idVoiture, ListVoiture** liste){
    int trouve=0;
    if(!(*liste))
        return 0;
    ListVoiture* tmp=*liste;
    if((*liste)->voiture.idVoiture==idVoiture){
        *liste=(*liste)->suivant;
        free(tmp);
        return 1;
    }
    while(tmp->suivant){
        if(tmp->suivant->voiture.idVoiture!=idVoiture)
            tmp=tmp->suivant;
        else {
            trouve=1;
            break;
        }
    }
    if(trouve==1){
        tmp->suivant=tmp->suivant->suivant;
        free(tmp->suivant);
        return 1;
    }
    return 0;
}

int modef_Voiture_List(ListVoiture** liste, int IdVoiture, char* marque, char* nomVoiture, char* couleur, int nbplaces, int prixJour, char* EnLocation){
    int trouve=0;
    ListVoiture* tmp=*liste;
    while(tmp){
        if(tmp->voiture.idVoiture==IdVoiture){
            trouve=1;
            break;
        }
        tmp=tmp->suivant;
    }
    if(trouve==0)
        return 0;
    tmp->voiture.idVoiture=IdVoiture;
    tmp->voiture.nbplaces=nbplaces;
    tmp->voiture.prixJour=prixJour;
    strcpy(tmp->voiture.couleur,couleur);
    strcpy(tmp->voiture.EnLocation,EnLocation);
    strcpy(tmp->voiture.marque,marque);
    strcpy(tmp->voiture.nomVoiture,nomVoiture);
    return 1;
}

int modef_Voiture_Etat_Location(ListVoiture** liste, int IdVoiture, char* EnLocation){
    int trouve=0;
    ListVoiture* tmp=*liste;
    while(tmp){
        if(tmp->voiture.idVoiture==IdVoiture){
            trouve=1;
            break;
        }
        tmp=tmp->suivant;
    }
    if(trouve==0)
        return 0;
    strcpy(tmp->voiture.EnLocation,EnLocation);
    return 1;
}

void init_voiture(ListVoiture** liste_total_voiture){
    char data[30];
    Voiture voiture;
    FILE *fvoiture=NULL;
    fvoiture = fopen(VoitureFile ,"r");
    if(fvoiture==NULL){
        fvoiture = fopen(VoitureFile ,"w");
        fclose(fvoiture);
        fvoiture = fopen(VoitureFile ,"r");
    }
    while(fgets(data,30,fvoiture)){
        voiture.idVoiture=atoi(data);

        fgets(data,30,fvoiture);
        chomp(data);
        strcpy(voiture.marque, data);

        fgets(data,30,fvoiture);
        chomp(data);
        strcpy(voiture.nomVoiture, data);

        fgets(data,30,fvoiture);
        chomp(data);
        strcpy(voiture.couleur, data);

        fgets(data,30,fvoiture);
        voiture.nbplaces=atoi(data);

        fgets(data,30,fvoiture);
        voiture.prixJour=atoi(data);

        fgets(data,30,fvoiture);
        chomp(data);
        strcpy(voiture.EnLocation, data);

        ajout_Voiture_List(voiture, liste_total_voiture);
    }
    fclose(fvoiture);
}

void exit_voiture(ListVoiture* liste_total_voiture, void (*afficheVoitureArbre)(ArbreVoiture*, FILE *)){
    FILE *fvoiture=NULL;
    fvoiture = fopen(VoitureFile ,"w");
    ArbreVoiture* arbVoiture=NULL;
    while(liste_total_voiture){
        inserVoitureArbre(&arbVoiture, liste_total_voiture->voiture);
        liste_total_voiture=liste_total_voiture->suivant;
    }
    (*afficheVoitureArbre)(arbVoiture, fvoiture);
    fclose(fvoiture);

}

#endif // VOITURE_H_INCLUDED
