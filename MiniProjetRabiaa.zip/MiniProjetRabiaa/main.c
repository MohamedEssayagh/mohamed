#include <stdlib.h>
#include <gtk/gtk.h>
#include "Location.h"
#include <string.h>
#include<stdio.h>



int main (int argc, char *argv[])
{
    //interfaceAjouterClient(argc, argv);
    MenuGestionLocationVoiture(argc, argv);
    //int e=!strcmp("Hamza","Hamza");
    //printf("%d",e);

    return 0;
}








