#ifndef LOCATION_H_INCLUDED
#define LOCATION_H_INCLUDED
#include <stdlib.h>
#include "Client.h"
#include "Voiture.h"
#include "Date.h"
#include <gtk/gtk.h>

#define LocationFile "location.txt"

typedef struct{
        GtkEntry* t1;
        GtkEntry* t2;
        GtkEntry* t3;
        GtkEntry* t4;
        GtkEntry* t5;
        GtkEntry* t6;
        GtkEntry* t7;
        GtkEntry* t8;
        GtkEntry* t9;
        GtkEntry* t10;
        GtkEntry* t11;
        GtkEntry* t12;
        GtkWidget* f1;
        int idClient;
        int idVoiture;
        int numContrat;
        int argc;
        char **argv;
    }data;

typedef struct ContratLocation{
 int numContrat;
 int idVoiture;
 int idClient;
 Date debut;
 Date fin;
 int couts;
}ContratLocation;


typedef struct Contrats{
    ContratLocation contratLocation;
    struct Contrats* suivant;
}ListContrats;

typedef struct ArbreContrat{
    ContratLocation contrat;
    struct ArbreContrat* right;
    struct ArbreContrat* left;
}ArbreContrat;

int inserContratArbre(ArbreContrat** arbreContrat, ContratLocation contrat){
    if((*arbreContrat)==NULL){
        *arbreContrat=(ArbreContrat*)malloc(sizeof(ArbreContrat));
        if(*arbreContrat==NULL)
            exit(0);
        (*arbreContrat)->left=NULL;
        (*arbreContrat)->right=NULL;
        (*arbreContrat)->contrat.numContrat=contrat.numContrat;
        (*arbreContrat)->contrat.idClient=contrat.idClient;
        (*arbreContrat)->contrat.idVoiture=contrat.idVoiture;
        (*arbreContrat)->contrat.couts=contrat.couts;
        datecpy(&((*arbreContrat)->contrat.debut), &(contrat.debut));
        datecpy(&((*arbreContrat)->contrat.fin), &(contrat.fin));
        return 1;
    }else if((*arbreContrat)->contrat.numContrat>contrat.numContrat)
            inserContratArbre((&(*arbreContrat)->left), contrat);
        else inserContratArbre((&(*arbreContrat)->right), contrat);
}

void afficheContratArbre(ArbreContrat* arbreContrat, FILE* fcontrat){
    if(arbreContrat!=NULL){
        afficheContratArbre(arbreContrat->left, fcontrat);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.numContrat);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.idClient);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.idVoiture);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.debut.jour);
        fprintf(fcontrat,"%s\n",arbreContrat->contrat.debut.mois);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.debut.annee);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.fin.jour);
        fprintf(fcontrat,"%s\n",arbreContrat->contrat.fin.mois);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.fin.annee);
        fprintf(fcontrat,"%d\n",arbreContrat->contrat.couts);
        afficheContratArbre(arbreContrat->right, fcontrat);
    }
}

ListVoiture* liste_total_voiture;
ListClient* liste_total_client;
ListContrats* liste_contrats;

int affiche_contrat_location(int numContrat, ListContrats* contrat, char* infoContrat){
    Client* client;
    Voiture* voiture;
    char strTmp1[500]="";
    char strTmp2[500]="";
    char strTmp3[1000]="";
    while(contrat){
        if(contrat->contratLocation.numContrat==numContrat){
            client=trouverClientId(liste_total_client, contrat->contratLocation.idClient);
            voiture=trovuerVoitureId(liste_total_voiture, contrat->contratLocation.idVoiture);
            affiche_client_contrat(*client, strTmp1);
            affiche_voiture_contrat(*voiture, strTmp2);
            sprintf(strTmp3,"Id Contrat %d\n%sPeriode d'Allocation %d/%s/%d jusqu'a %d/%s/%d\n%scout: %dDhs",
                    numContrat, strTmp1,contrat->contratLocation.debut.jour, contrat->contratLocation.debut.mois, contrat->contratLocation.debut.annee
                    ,contrat->contratLocation.fin.jour, contrat->contratLocation.fin.mois, contrat->contratLocation.fin.annee, strTmp2, contrat->contratLocation.couts);
            strcat(infoContrat, strTmp3);
            return 1;
        }
        contrat=contrat->suivant;
    }
    //printf("Il y a aucun contrat pour le moment.");
    return 0;
}

ContratLocation* trouverContratId(ListContrats* liste_contrats, int numContrat){
    while(liste_contrats){
        if(liste_contrats->contratLocation.numContrat==numContrat)
            return &liste_contrats->contratLocation;
        liste_contrats=liste_contrats->suivant;
    }
    return NULL;
}

int calcule_cout(int prixJour, Date debut, Date fin){
    int nombreJour=0;
    if(debut.moisN==fin.moisN)
        nombreJour=fin.jour-debut.jour;
    else if(debut.moisN<fin.moisN){
            if((fin.moisN-debut.moisN)==1)
                nombreJour=debut.nbrJour-debut.jour+fin.jour;
            else if((fin.moisN-debut.moisN)>1)
                    nombreJour=debut.nbrJour-debut.jour+fin.jour+(fin.moisN-debut.moisN-1)*30;
    }
    return prixJour*nombreJour;
}

int ajouter_Contrat_List(ListContrats** liste, ContratLocation* contrat){
    ListContrats* tmp=NULL;
    tmp=(ListContrats*)malloc(sizeof(ListContrats));
    if(tmp==NULL)
        return 0;
    tmp->contratLocation.numContrat=contrat->numContrat;
    tmp->contratLocation.idVoiture=contrat->idVoiture;
    tmp->contratLocation.idClient=contrat->idClient;
    datecpy(&tmp->contratLocation.debut, &(contrat->debut));
    datecpy(&tmp->contratLocation.fin, &(contrat->fin));
    tmp->contratLocation.couts=contrat->couts;
    tmp->suivant=NULL;
    /*La liste est vide*/
    if(!(*liste))
        *liste=tmp;
    else{//ajouter en tete de la liste
        ListContrats* tmp1=*liste;
        while(tmp1->suivant)
            tmp1=tmp1->suivant;
        tmp1->suivant=tmp;
    }
    return 1;
}

int louer_voiture(char* nom, char* prenom, char* marque, char* nomVoiture, char* couleur, int nbplaces, Date debut, Date fin, int* numContrat){
    int counts=trouveVoitureNom(liste_total_voiture, marque, nomVoiture, couleur, nbplaces);
    if(counts==0)
        return 0;// 0 �a veut dire que la voiture n'existe
    int idClient=trouveClientParNom(liste_total_client, nom, prenom);
    if(idClient==0)
        return 1;// 1 ca veut dire que la voiture existe mais le client n'exite pas
    //ici le client exite et la voiture aussi il faut verifier la disponibilit� de la voiture
    int idVoiture=trouveVoitureNomID(liste_total_voiture, marque, nomVoiture, couleur, nbplaces);
    if(idVoiture==0)
        return 2;
    //2 ca veut dire que la voiture n'est pas disponible
    //ici la voiture est disponible et le client est enregister
    //1) changer le statu dela voiture allouer
    Voiture* voiture=trovuerVoitureId(liste_total_voiture, idVoiture);
    modef_Voiture_Etat_Location(&liste_total_voiture, idVoiture, "Oui");
    //2)
    ContratLocation contrat;
    contrat.idClient=idClient;
    contrat.idVoiture=idVoiture;
    contrat.numContrat=(int)(rand()%10000);
    *numContrat=contrat.numContrat;
    datecpy(&contrat.debut,&debut);
    datecpy(&contrat.fin,&fin);
    contrat.couts=calcule_cout(voiture->prixJour, debut, fin);
    ajouter_Contrat_List(&liste_contrats,&contrat);
    return 3;//3 �a veut dire que la voiture est bien ete allouer et le contrat a ete ajout�
}

int modef_Contrat_List(ListContrats** liste, int numContrat, Date fin){
    int trouve=0;
    ListContrats* tmp=*liste;
    while(tmp){
        if(tmp->contratLocation.numContrat==numContrat){
            trouve=1;
            break;
        }
        tmp=tmp->suivant;
    }
    if(trouve==0)
        return 0;
    if(tmp->contratLocation.debut.moisN>fin.moisN)
        return 1;
    if(tmp->contratLocation.debut.moisN==fin.moisN && tmp->contratLocation.debut.jour>fin.jour)
        return 1;
    datecpy(&tmp->contratLocation.fin,&fin);
    tmp->contratLocation.couts= calcule_cout(trovuerVoitureId(liste_total_voiture, tmp->contratLocation.idVoiture)->prixJour, tmp->contratLocation.debut, tmp->contratLocation.fin);
    return 2;
}

int supprimer_contrat_location_List(int numContrat, ListContrats** liste){
    int trouve=0;
    if(!(*liste))
        return 0;
    ListContrats* tmp=*liste;
    if((*liste)->contratLocation.numContrat==numContrat){
        *liste=(*liste)->suivant;
        modef_Voiture_Etat_Location(&liste_total_voiture, tmp->contratLocation.idVoiture, "Non");
        free(tmp);
        return 1;
    }
    while(tmp->suivant){
        if(tmp->suivant->contratLocation.numContrat!=numContrat)
            tmp=tmp->suivant;
        else {
            trouve=1;
            break;
        }
    }
    if(trouve==1){
        tmp->suivant=tmp->suivant->suivant;
        modef_Voiture_Etat_Location(&liste_total_voiture, tmp->contratLocation.idVoiture, "Non");
        free(tmp->suivant);
        return 1;
    }
    return 0;
}

int retourner_voiture_louer(int numContrat, ListContrats** liste){
    return supprimer_contrat_location_List(numContrat, liste);
}

void init_contrat(ListContrats** liste_contrats){
    init_client(&liste_total_client);
    init_voiture(&liste_total_voiture);
    char data[30];
    ContratLocation contrat;
    FILE *fcontrat=NULL;
    fcontrat = fopen(LocationFile, "r");
    if(fcontrat==NULL){
        //printf("le fichier n'existe pas, on va cr�er un pour vous\n");
        fcontrat = fopen(LocationFile ,"w");
        fclose(fcontrat);
        fcontrat = fopen(LocationFile ,"r");
    }
    while(fgets(data,30,fcontrat)){//fgets(data,30,fclient) fscanf(fclient,"%d\n",data)
        contrat.numContrat=atoi(data);

        fgets(data,30,fcontrat);
        contrat.idClient=atoi(data);

        fgets(data,30,fcontrat);
        contrat.idVoiture=atoi(data);

        fgets(data,30,fcontrat);
        contrat.debut.jour=atoi(data);

        fgets(data,30,fcontrat);
        chomp_(data);
        strcpy(contrat.debut.mois, data);

        fgets(data,30,fcontrat);
        contrat.debut.annee=atoi(data);

        fgets(data,30,fcontrat);
        contrat.fin.jour=atoi(data);

        fgets(data,30,fcontrat);
        chomp_(data);
        strcpy(contrat.fin.mois, data);

        fgets(data,30,fcontrat);
        contrat.fin.annee=atoi(data);

        fgets(data,30,fcontrat);
        contrat.couts=atoi(data);

        mois_moisN(&(contrat.debut));
        mois_moisN(&(contrat.fin));
       ajouter_Contrat_List(liste_contrats, &contrat);
    }
    fclose(fcontrat);
}

void exit_contrat(ListContrats* liste_contrats, void (*afficheContratArbre)(ArbreContrat*, FILE*)){
    exit_client(liste_total_client, &afficheClientArbre);
    ArbreVoiture* arbVoiture=NULL;
    exit_voiture(liste_total_voiture, &afficheVoitureArbre);
    ArbreContrat* arbContrat=NULL;
    FILE* fcontrat = fopen(LocationFile ,"w");
    while(liste_contrats){
        inserContratArbre(&arbContrat, liste_contrats->contratLocation);
        liste_contrats=liste_contrats->suivant;
    }
    (*afficheContratArbre)(arbContrat, fcontrat);
    fclose(fcontrat);
}

void interfaceBoitDialog(GtkWidget* f1, char* message){
    guint reponse = GTK_RESPONSE_NONE;
    GtkWidget* confirme=gtk_message_dialog_new(f1, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, message);
    reponse=gtk_dialog_run(GTK_DIALOG(confirme));
    gtk_widget_destroy(confirme);
    return;
}

void b1_clic_ajoutClient( GtkWidget * bouton, gpointer userdata){
    data* entry=(data*)userdata;
    int idClient=(int)(rand()%1000);
    const char* nom=(char*)gtk_entry_get_text(entry->t1);
    const char* prenom=(char*)gtk_entry_get_text(entry->t2);
    int cine=(int)atoi((char*)gtk_entry_get_text(entry->t3));
    const char* adresse=(char*)gtk_entry_get_text(entry->t4);
    const char* telephone=(char*)gtk_entry_get_text(entry->t5);
    Client client;
    client.idClient=idClient;
    client.cine=cine;
    strcpy(client.nom, nom);
    strcpy(client.prenom, prenom);
    strcpy(client.adresse, adresse);
    strcpy(client.telephone, telephone);
    ajout_Client_List(client, &liste_total_client);
    interfaceBoitDialog(entry->f1, "Le Client a ete bien ajoute");
    gtk_entry_set_text(entry->t1,"");
    gtk_entry_set_text(entry->t2,"");
    gtk_entry_set_text(entry->t3,"");
    gtk_entry_set_text(entry->t4,"");
    gtk_entry_set_text(entry->t5,"");
}

void b1_clic_ModefClient( GtkWidget * bouton, gpointer userdata ){
    data* entry=(data*)userdata;
    int idClient=entry->idClient;
    const char* nom=(char*)gtk_entry_get_text(entry->t1);
    const char* prenom=(char*)gtk_entry_get_text(entry->t2);
    int cine=(int)atoi((char*)gtk_entry_get_text(entry->t3));
    const char* adresse=(char*)gtk_entry_get_text(entry->t4);
    const char* telephone=(char*)gtk_entry_get_text(entry->t5);
    Client client;
    client.idClient=idClient;
    client.cine=cine;
    strcpy(client.nom, nom);
    strcpy(client.prenom, prenom);
    strcpy(client.adresse, adresse);
    strcpy(client.telephone, telephone);
    modef_Client_List(&liste_total_client, idClient, nom, prenom, cine, adresse, telephone);
    interfaceBoitDialog(entry->f1, "Le Client a ete bien modefier");
    gtk_entry_set_text(entry->t1,"");
    gtk_entry_set_text(entry->t2,"");
    gtk_entry_set_text(entry->t3,"");
    gtk_entry_set_text(entry->t4,"");
    gtk_entry_set_text(entry->t5,"");
}

void b1_clic_ajoutVoiture( GtkWidget * bouton, gpointer userdata ){
    data* entry=(data*)userdata;
    int idVoiture=(int)(rand()%1000);
    const char* marque=(char*)gtk_entry_get_text(entry->t1);
    const char* nomVoiture=(char*)gtk_entry_get_text(entry->t2);
    const char* couleur=(char*)gtk_entry_get_text(entry->t3);
    int nbplaces=(int)atoi((char*)gtk_entry_get_text(entry->t4));
    int prixJour=(int)atoi((char*)gtk_entry_get_text(entry->t5));
    char* EnLocation="Non";
    Voiture voiture;
    voiture.idVoiture=idVoiture;
    strcpy(voiture.marque, marque);
    strcpy(voiture.nomVoiture, nomVoiture);
    strcpy(voiture.EnLocation, EnLocation);
    strcpy(voiture.couleur, couleur);
    voiture.prixJour=prixJour;
    voiture.nbplaces=nbplaces;
    ajout_Voiture_List(voiture, &liste_total_voiture);
    interfaceBoitDialog(entry->f1, "Le Voiture a ete bien ajoute");
    gtk_entry_set_text(entry->t1,"");
    gtk_entry_set_text(entry->t2,"");
    gtk_entry_set_text(entry->t3,"");
    gtk_entry_set_text(entry->t4,"");
    gtk_entry_set_text(entry->t5,"");
}

void b1_clic_ModefierVoiture( GtkWidget * bouton, gpointer userdata ){
    data* entry=(data*)userdata;
    int idVoiture=entry->idVoiture;
    const char* marque=(char*)gtk_entry_get_text(entry->t1);
    const char* nomVoiture=(char*)gtk_entry_get_text(entry->t2);
    const char* couleur=(char*)gtk_entry_get_text(entry->t3);
    int nbplaces=(int)atoi((char*)gtk_entry_get_text(entry->t4));
    int prixJour=(int)atoi((char*)gtk_entry_get_text(entry->t5));
    char* EnLocation=(char*)gtk_entry_get_text(entry->t6);
    Voiture voiture;
    voiture.idVoiture=idVoiture;
    strcpy(voiture.marque, marque);
    strcpy(voiture.nomVoiture, nomVoiture);
    strcpy(voiture.EnLocation, EnLocation);
    strcpy(voiture.couleur, couleur);
    voiture.prixJour=prixJour;
    voiture.nbplaces=nbplaces;
    modef_Voiture_List(&liste_total_voiture, idVoiture, marque, nomVoiture, couleur, nbplaces, prixJour, EnLocation);
    interfaceBoitDialog(entry->f1, "Le Voiture a ete bien modefier");
    gtk_entry_set_text(entry->t1,"");
    gtk_entry_set_text(entry->t2,"");
    gtk_entry_set_text(entry->t3,"");
    gtk_entry_set_text(entry->t4,"");
    gtk_entry_set_text(entry->t5,"");
    gtk_entry_set_text(entry->t6,"");
}

void b1_clic_allouerVoiture( GtkWidget * bouton, gpointer userdata){
    data* entry=(data*)userdata;
    Date debut;
    Date fin;
    int numConntra;
    entry->numContrat=numConntra;
    const char* nom=(char*)gtk_entry_get_text(entry->t1);
    const char* prenom=(char*)gtk_entry_get_text(entry->t2);
    const char* marque=(char*)gtk_entry_get_text(entry->t3);
    const char* nomVoiture=(char*)gtk_entry_get_text(entry->t4);
    const char* couleur=(char*)gtk_entry_get_text(entry->t5);
    int nombrePlace=(int)atoi((char*)gtk_entry_get_text(entry->t6));
    debut.jour=(int)atoi((char*)gtk_entry_get_text(entry->t7));
    strcpy(debut.mois,(char*)gtk_entry_get_text(entry->t8));
    debut.annee=(int)atoi((char*)gtk_entry_get_text(entry->t9));
    mois_moisN(&debut);
    fin.jour=(int)atoi((char*)gtk_entry_get_text(entry->t10));
    strcpy(fin.mois,(char*)gtk_entry_get_text(entry->t11));
    fin.annee=(int)atoi((char*)gtk_entry_get_text(entry->t12));
    mois_moisN(&fin);
    int faux_date=-1;
    if(debut.annee>fin.annee)
        faux_date=0;
    else if(debut.annee==fin.annee){
            if(debut.moisN>fin.moisN)
                faux_date=0;
            else if(debut.moisN==fin.moisN){
                    if(debut.jour>fin.jour)
                        faux_date=0;
            }

    }
    if(faux_date==0){
        interfaceBoitDialog(entry->f1, "La date fin d'allocation ne doit pas etre avant la date debut d'allocation !");
        return;
    }
    int etat=louer_voiture(nom, prenom, marque, nomVoiture, couleur, nombrePlace, debut, fin, &numConntra);
    if(etat==0)
        interfaceBoitDialog(entry->f1, "La voiture demande n'existe pas");
    else if(etat==1){
        interfaceBoitDialog(entry->f1, "Veuillez enregister le client sans la section Gestion Client");
        interfaceAjouterClient(entry->argc, entry->argv);
    }
    else if(etat==2)
        interfaceBoitDialog(entry->f1, "La Voiture demandee est deja allouer");
    else if(etat==3){
        char strTmp[100]="";
            sprintf(strTmp,"L'Allocation de la voiture a ete effectuee avec succes. Le numero de contrat est: %d", numConntra);
            interfaceBoitDialog(entry->f1, strTmp);
            gtk_entry_set_text(entry->t1,"");
            gtk_entry_set_text(entry->t2,"");
            gtk_entry_set_text(entry->t3,"");
            gtk_entry_set_text(entry->t4,"");
            gtk_entry_set_text(entry->t5,"");
            gtk_entry_set_text(entry->t6,"");
            gtk_entry_set_text(entry->t7,"");
            gtk_entry_set_text(entry->t8,"");
            gtk_entry_set_text(entry->t9,"");
            gtk_entry_set_text(entry->t10,"");
            gtk_entry_set_text(entry->t11,"");
            gtk_entry_set_text(entry->t12,"");
    }
}

void b1_clic_ModefallouerVoiture( GtkWidget * bouton, gpointer userdata){
    data* entry=(data*)userdata;
    Date fin, debut;
    fin.jour=(int)atoi((char*)gtk_entry_get_text(entry->t10));
    strcpy(fin.mois,(char*)gtk_entry_get_text(entry->t11));
    fin.annee=(int)atoi((char*)gtk_entry_get_text(entry->t12));
    mois_moisN(&fin);
    debut.jour=(int)atoi((char*)gtk_entry_get_text(entry->t7));
    strcpy(debut.mois,(char*)gtk_entry_get_text(entry->t8));
    debut.annee=(int)atoi((char*)gtk_entry_get_text(entry->t9));
    mois_moisN(&debut);

    int faux_date=-1;
    if(debut.annee>fin.annee)
        faux_date=0;
    else if(debut.annee==fin.annee){
            if(debut.moisN>fin.moisN)
                faux_date=0;
            else if(debut.moisN==fin.moisN){
                    if(debut.jour>fin.jour)
                        faux_date=0;
            }

    }
    if(faux_date==0){
        interfaceBoitDialog(entry->f1, "La date fin d'allocation ne doit pas etre avant la date debut d'allocation !");
        return;
    }
    int etat= modef_Contrat_List(&liste_contrats, entry->numContrat, fin);
    if(etat==1)
        interfaceBoitDialog(entry->f1, "La date fin d'allocation ne doit etre avant la date debut d'allocation");
    else if(etat==2){
            interfaceBoitDialog(entry->f1, "La Modefication du contrat d'allocation a ete effectue avec succes");
            //printf("1\n");
            gtk_entry_set_text(entry->t1,"");
            //printf("2\n");
            gtk_entry_set_text(entry->t2,"");
            //printf("3\n");
            gtk_entry_set_text(entry->t3,"");
            //printf("4\n");
            gtk_entry_set_text(entry->t4,"");
            //printf("5\n");
            gtk_entry_set_text(entry->t5,"");
            //printf("6\n");
            gtk_entry_set_text(entry->t6,"");
            //printf("7\n");
            gtk_entry_set_text(entry->t7,"");
            //printf("8\n");
            gtk_entry_set_text(entry->t8,"");
            //printf("9\n");
            gtk_entry_set_text(entry->t9,"");
            //printf("10\n");
            gtk_entry_set_text(entry->t10,"");
            //printf("11\n");
            gtk_entry_set_text(entry->t11,"");
            //printf("12\n");
            gtk_entry_set_text(entry->t12,"");
    }
}

void interfaceAllouerVoiture(int argc, char**argv){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->argc=argc;
    entry->argv=argv;
    //*creation de la fentre:
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Allouer une Voiture");
    gtk_window_set_default_size(entry->f1, 300, 300);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new("Nom du client:");
    GtkWidget* l2=gtk_label_new("Prenom du client:");
    GtkWidget* l3=gtk_label_new("La Marque de Voiture:");
    GtkWidget* l4=gtk_label_new("Le Nom de Voiture");
    GtkWidget* l5=gtk_label_new("Couleur:");
    GtkWidget* l6=gtk_label_new("Nombre de Places:");
    GtkWidget* l7=gtk_label_new("Date Debut:");
    GtkWidget* l8=gtk_label_new("Jour:");
    GtkWidget* l9=gtk_label_new("Mois:");
    GtkWidget* l10=gtk_label_new("Annee:");
    GtkWidget* l11=gtk_label_new("Date Fin:");
    GtkWidget* l12=gtk_label_new("Jour:");
    GtkWidget* l13=gtk_label_new("Mois:");
    GtkWidget* l14=gtk_label_new("Annee:");
    GtkWidget* b1=gtk_button_new_with_label ("Allouer la Voiture");
    entry->t1=gtk_entry_new();
    entry->t2=gtk_entry_new();
    entry->t3=gtk_entry_new();
    entry->t4=gtk_entry_new();
    entry->t5=gtk_entry_new();
    entry->t6=gtk_entry_new();
    entry->t7=gtk_entry_new();
    entry->t8=gtk_entry_new();
    entry->t9=gtk_entry_new();
    entry->t10=gtk_entry_new();
    entry->t11=gtk_entry_new();
    entry->t12=gtk_entry_new();
    GtkWidget* p1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p2=gtk_hbox_new(TRUE, 0);
    GtkWidget* p3=gtk_hbox_new(TRUE, 0);
    GtkWidget* p4=gtk_hbox_new(TRUE, 0);
    GtkWidget* p5=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6=gtk_hbox_new(TRUE, 0);
    GtkWidget* p7=gtk_hbox_new(TRUE, 0);
    GtkWidget* p8=gtk_hbox_new(TRUE, 0);
    GtkWidget* p9=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p1), l1); gtk_container_add(GTK_CONTAINER(p1), entry->t1);
    gtk_container_add(GTK_CONTAINER(p2), l2); gtk_container_add(GTK_CONTAINER(p2), entry->t2);
    gtk_container_add(GTK_CONTAINER(p3), l3); gtk_container_add(GTK_CONTAINER(p3), entry->t3);
    gtk_container_add(GTK_CONTAINER(p4), l4); gtk_container_add(GTK_CONTAINER(p4), entry->t4);
    gtk_container_add(GTK_CONTAINER(p5), l5); gtk_container_add(GTK_CONTAINER(p5), entry->t5);
    gtk_container_add(GTK_CONTAINER(p6), l6); gtk_container_add(GTK_CONTAINER(p6), entry->t6);

    gtk_container_add(GTK_CONTAINER(p7), l7);
    gtk_container_add(GTK_CONTAINER(p7), l8);  gtk_container_add(GTK_CONTAINER(p7), entry->t7);
    gtk_container_add(GTK_CONTAINER(p7), l9);  gtk_container_add(GTK_CONTAINER(p7), entry->t8);
    gtk_container_add(GTK_CONTAINER(p7), l10); gtk_container_add(GTK_CONTAINER(p7), entry->t9);

    gtk_container_add(GTK_CONTAINER(p8), l11);
    gtk_container_add(GTK_CONTAINER(p8), l12);  gtk_container_add(GTK_CONTAINER(p8), entry->t10);
    gtk_container_add(GTK_CONTAINER(p8), l13);  gtk_container_add(GTK_CONTAINER(p8), entry->t11);
    gtk_container_add(GTK_CONTAINER(p8), l14); gtk_container_add(GTK_CONTAINER(p8), entry->t12);


    gtk_container_add(GTK_CONTAINER(p9),p1);
    gtk_container_add(GTK_CONTAINER(p9),p2);
    gtk_container_add(GTK_CONTAINER(p9),p3);
    gtk_container_add(GTK_CONTAINER(p9),p4);
    gtk_container_add(GTK_CONTAINER(p9),p5);
    gtk_container_add(GTK_CONTAINER(p9),p6);
    gtk_container_add(GTK_CONTAINER(p9),p7);
    gtk_container_add(GTK_CONTAINER(p9),p8);
    gtk_container_add(GTK_CONTAINER(p9),b1);
    gtk_container_add(GTK_CONTAINER(entry->f1), p9);
    gtk_signal_connect(G_OBJECT(b1), "clicked",G_CALLBACK(b1_clic_allouerVoiture) ,entry);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceModefAllouerVoiture(int argc, char**argv, Client client, Voiture voiture, ContratLocation contrat){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->argc=argc;
    entry->argv=argv;
    entry->numContrat=contrat.numContrat;
    //*creation de la fentre:
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Modefier le Contrat d'Allouer une Voiture");
    gtk_window_set_default_size(entry->f1, 300, 300);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new("Nom du client:");
    GtkWidget* l2=gtk_label_new("Prenom du client:");
    GtkWidget* l3=gtk_label_new("La Marque de Voiture:");
    GtkWidget* l4=gtk_label_new("Le Nom de Voiture");
    GtkWidget* l5=gtk_label_new("Couleur:");
    GtkWidget* l6=gtk_label_new("Nombre de Places:");
    GtkWidget* l7=gtk_label_new("Date Debut:");
    GtkWidget* l8=gtk_label_new("Jour:");
    GtkWidget* l9=gtk_label_new("Mois:");
    GtkWidget* l10=gtk_label_new("Annee:");
    GtkWidget* l11=gtk_label_new("Date Fin:");
    GtkWidget* l12=gtk_label_new("Jour:");
    GtkWidget* l13=gtk_label_new("Mois:");
    GtkWidget* l14=gtk_label_new("Annee:");
    GtkWidget* b1=gtk_button_new_with_label ("Modefier le Contrat d'Allouer la Voiture");
    entry->t1=gtk_entry_new(); gtk_entry_set_text(entry->t1, (gchar*)client.nom); gtk_entry_set_editable(entry->t1, FALSE);
    entry->t2=gtk_entry_new(); gtk_entry_set_text(entry->t2, (gchar*)client.prenom); gtk_entry_set_editable(entry->t2, FALSE);
    entry->t3=gtk_entry_new(); gtk_entry_set_text(entry->t3, (gchar*)voiture.marque); gtk_entry_set_editable(entry->t3, FALSE);
    entry->t4=gtk_entry_new(); gtk_entry_set_text(entry->t4, (gchar*)voiture.nomVoiture); gtk_entry_set_editable(entry->t4, FALSE);
    entry->t5=gtk_entry_new(); gtk_entry_set_text(entry->t5, (gchar*)voiture.couleur); gtk_entry_set_editable(entry->t5, FALSE);

    char str[20];
    sprintf(str,"%d",voiture.nbplaces);
    entry->t6=gtk_entry_new(); gtk_entry_set_text(entry->t6, (gchar*)str);  gtk_entry_set_editable(entry->t6, FALSE);

    char str1[20];
    sprintf(str1,"%d",contrat.debut.jour);
    entry->t7=gtk_entry_new(); gtk_entry_set_text(entry->t7,(gchar*)str1); gtk_entry_set_editable(entry->t7, FALSE);

    entry->t8=gtk_entry_new(); gtk_entry_set_text(entry->t8,(gchar*)contrat.debut.mois); gtk_entry_set_editable(entry->t8, FALSE);

    char str2[20];
    sprintf(str2,"%d",contrat.debut.annee);
    entry->t9=gtk_entry_new(); gtk_entry_set_text(entry->t9,(gchar*)str2); gtk_entry_set_editable(entry->t9, FALSE);

    char str3[20];
    sprintf(str3,"%d",contrat.fin.jour);
    entry->t10=gtk_entry_new(); gtk_entry_set_text(entry->t10,(gchar*)str3);

    entry->t11=gtk_entry_new(); gtk_entry_set_text(entry->t11,(gchar*)contrat.fin.mois);

    char str4[20];
    sprintf(str4,"%d",contrat.fin.annee);
    entry->t12=gtk_entry_new();gtk_entry_set_text(entry->t12, (gchar*)str4);

    GtkWidget* p1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p2=gtk_hbox_new(TRUE, 0);
    GtkWidget* p3=gtk_hbox_new(TRUE, 0);
    GtkWidget* p4=gtk_hbox_new(TRUE, 0);
    GtkWidget* p5=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6=gtk_hbox_new(TRUE, 0);
    GtkWidget* p7=gtk_hbox_new(TRUE, 0);
    GtkWidget* p8=gtk_hbox_new(TRUE, 0);
    GtkWidget* p9=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p1), l1); gtk_container_add(GTK_CONTAINER(p1), entry->t1);
    gtk_container_add(GTK_CONTAINER(p2), l2); gtk_container_add(GTK_CONTAINER(p2), entry->t2);
    gtk_container_add(GTK_CONTAINER(p3), l3); gtk_container_add(GTK_CONTAINER(p3), entry->t3);
    gtk_container_add(GTK_CONTAINER(p4), l4); gtk_container_add(GTK_CONTAINER(p4), entry->t4);
    gtk_container_add(GTK_CONTAINER(p5), l5); gtk_container_add(GTK_CONTAINER(p5), entry->t5);
    gtk_container_add(GTK_CONTAINER(p6), l6); gtk_container_add(GTK_CONTAINER(p6), entry->t6);

    gtk_container_add(GTK_CONTAINER(p7), l7);
    gtk_container_add(GTK_CONTAINER(p7), l8);  gtk_container_add(GTK_CONTAINER(p7), entry->t7);
    gtk_container_add(GTK_CONTAINER(p7), l9);  gtk_container_add(GTK_CONTAINER(p7), entry->t8);
    gtk_container_add(GTK_CONTAINER(p7), l10); gtk_container_add(GTK_CONTAINER(p7), entry->t9);

    gtk_container_add(GTK_CONTAINER(p8), l11);
    gtk_container_add(GTK_CONTAINER(p8), l12);  gtk_container_add(GTK_CONTAINER(p8), entry->t10);
    gtk_container_add(GTK_CONTAINER(p8), l13);  gtk_container_add(GTK_CONTAINER(p8), entry->t11);
    gtk_container_add(GTK_CONTAINER(p8), l14); gtk_container_add(GTK_CONTAINER(p8), entry->t12);


    gtk_container_add(GTK_CONTAINER(p9),p1);
    gtk_container_add(GTK_CONTAINER(p9),p2);
    gtk_container_add(GTK_CONTAINER(p9),p3);
    gtk_container_add(GTK_CONTAINER(p9),p4);
    gtk_container_add(GTK_CONTAINER(p9),p5);
    gtk_container_add(GTK_CONTAINER(p9),p6);
    gtk_container_add(GTK_CONTAINER(p9),p7);
    gtk_container_add(GTK_CONTAINER(p9),p8);
    gtk_container_add(GTK_CONTAINER(p9),b1);
    gtk_container_add(GTK_CONTAINER(entry->f1), p9);
    gtk_signal_connect(G_OBJECT(b1), "clicked",G_CALLBACK(b1_clic_ModefallouerVoiture) ,entry);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceAjouterClient(int argc, char**argv){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->argc=argc;
    entry->argv=argv;
    //*creation de la fentre:
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Ajouter un Nouveau Client");
    gtk_window_set_default_size(entry->f1, 200, 200);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new("Nom:");
    GtkWidget* l2=gtk_label_new("Prenom:");
    GtkWidget* l3=gtk_label_new("CIN:");
    GtkWidget* l4=gtk_label_new("Adresse:");
    GtkWidget* l5=gtk_label_new("Telephone:");
    GtkWidget* b1=gtk_button_new_with_label ("Ajouter Client");
    entry->t1=gtk_entry_new();
    entry->t2=gtk_entry_new();
    entry->t3=gtk_entry_new();
    entry->t4=gtk_entry_new();
    entry->t5=gtk_entry_new();
    GtkWidget* p1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p2=gtk_hbox_new(TRUE, 0);
    GtkWidget* p3=gtk_hbox_new(TRUE, 0);
    GtkWidget* p4=gtk_hbox_new(TRUE, 0);
    GtkWidget* p5=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6=gtk_hbox_new(TRUE, 0);
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p1), l1); gtk_container_add(GTK_CONTAINER(p1), entry->t1);
    gtk_container_add(GTK_CONTAINER(p2), l2); gtk_container_add(GTK_CONTAINER(p2), entry->t2);
    gtk_container_add(GTK_CONTAINER(p3), l3); gtk_container_add(GTK_CONTAINER(p3), entry->t3);
    gtk_container_add(GTK_CONTAINER(p4), l4); gtk_container_add(GTK_CONTAINER(p4), entry->t4);
    gtk_container_add(GTK_CONTAINER(p5), l5); gtk_container_add(GTK_CONTAINER(p5), entry->t5);
    gtk_container_add(GTK_CONTAINER(p6), b1);
    gtk_container_add(GTK_CONTAINER(p7),p1);
    gtk_container_add(GTK_CONTAINER(p7),p2);
    gtk_container_add(GTK_CONTAINER(p7),p3);
    gtk_container_add(GTK_CONTAINER(p7),p4);
    gtk_container_add(GTK_CONTAINER(p7),p5);
    gtk_container_add(GTK_CONTAINER(p7),p6);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    gtk_signal_connect(G_OBJECT(b1), "clicked",G_CALLBACK(b1_clic_ajoutClient) ,entry);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceModefierClient(int argc, char**argv, Client client){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->argc=argc;
    entry->argv=argv;
    //*creation de la fentre:
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Modefier un Client");
    gtk_window_set_default_size(entry->f1, 200, 200);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new("Nom:");
    GtkWidget* l2=gtk_label_new("Prenom:");
    GtkWidget* l3=gtk_label_new("CIN:");
    GtkWidget* l4=gtk_label_new("Adresse:");
    GtkWidget* l5=gtk_label_new("Telephone:");
    GtkWidget* b1=gtk_button_new_with_label ("Modefier Client");
    entry->t1=gtk_entry_new();
    entry->t2=gtk_entry_new();
    entry->t3=gtk_entry_new();
    entry->t4=gtk_entry_new();
    entry->t5=gtk_entry_new();
    gtk_entry_set_text(entry->t1, (gchar*)client.nom);
    gtk_entry_set_text(entry->t2, (gchar*)client.prenom);
    char str[20];
    sprintf(str,"%d",client.cine);
    gtk_entry_set_text(entry->t3, (gchar*)str);
    gtk_entry_set_text(entry->t4, (gchar*)client.adresse);
    gtk_entry_set_text(entry->t5, (gchar*)client.telephone);
    entry->idClient=client.idClient;
    GtkWidget* p1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p2=gtk_hbox_new(TRUE, 0);
    GtkWidget* p3=gtk_hbox_new(TRUE, 0);
    GtkWidget* p4=gtk_hbox_new(TRUE, 0);
    GtkWidget* p5=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6=gtk_hbox_new(TRUE, 0);
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p1), l1); gtk_container_add(GTK_CONTAINER(p1), entry->t1);
    gtk_container_add(GTK_CONTAINER(p2), l2); gtk_container_add(GTK_CONTAINER(p2), entry->t2);
    gtk_container_add(GTK_CONTAINER(p3), l3); gtk_container_add(GTK_CONTAINER(p3), entry->t3);
    gtk_container_add(GTK_CONTAINER(p4), l4); gtk_container_add(GTK_CONTAINER(p4), entry->t4);
    gtk_container_add(GTK_CONTAINER(p5), l5); gtk_container_add(GTK_CONTAINER(p5), entry->t5);
    gtk_container_add(GTK_CONTAINER(p6), b1);
    gtk_container_add(GTK_CONTAINER(p7),p1);
    gtk_container_add(GTK_CONTAINER(p7),p2);
    gtk_container_add(GTK_CONTAINER(p7),p3);
    gtk_container_add(GTK_CONTAINER(p7),p4);
    gtk_container_add(GTK_CONTAINER(p7),p5);
    gtk_container_add(GTK_CONTAINER(p7),p6);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    gtk_signal_connect(G_OBJECT(b1), "clicked",G_CALLBACK(b1_clic_ModefClient) ,entry);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceAjouterVoiture(int argc, char**argv){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->argc=argc;
    entry->argv=argv;
    //*creation de la fentre:
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Ajouter un Nouveau Voiture");
    gtk_window_set_default_size(entry->f1, 200, 200);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new("La Marque:");
    GtkWidget* l2=gtk_label_new("Nom de la Voiture:");
    GtkWidget* l3=gtk_label_new("Couleur");
    GtkWidget* l4=gtk_label_new("Nombre de Places");
    GtkWidget* l5=gtk_label_new("Prix par Jour");
    GtkWidget* b1=gtk_button_new_with_label ("Ajouter Voiture");
    entry->t1=gtk_entry_new();
    entry->t2=gtk_entry_new();
    entry->t3=gtk_entry_new();
    entry->t4=gtk_entry_new();
    entry->t5=gtk_entry_new();
    GtkWidget* p1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p2=gtk_hbox_new(TRUE, 0);
    GtkWidget* p3=gtk_hbox_new(TRUE, 0);
    GtkWidget* p4=gtk_hbox_new(TRUE, 0);
    GtkWidget* p5=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6=gtk_hbox_new(TRUE, 0);
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p1), l1); gtk_container_add(GTK_CONTAINER(p1), entry->t1);
    gtk_container_add(GTK_CONTAINER(p2), l2); gtk_container_add(GTK_CONTAINER(p2), entry->t2);
    gtk_container_add(GTK_CONTAINER(p3), l3); gtk_container_add(GTK_CONTAINER(p3), entry->t3);
    gtk_container_add(GTK_CONTAINER(p4), l4); gtk_container_add(GTK_CONTAINER(p4), entry->t4);
    gtk_container_add(GTK_CONTAINER(p5), l5); gtk_container_add(GTK_CONTAINER(p5), entry->t5);
    gtk_container_add(GTK_CONTAINER(p6), b1);
    gtk_container_add(GTK_CONTAINER(p7),p1);
    gtk_container_add(GTK_CONTAINER(p7),p2);
    gtk_container_add(GTK_CONTAINER(p7),p3);
    gtk_container_add(GTK_CONTAINER(p7),p4);
    gtk_container_add(GTK_CONTAINER(p7),p5);
    gtk_container_add(GTK_CONTAINER(p7),p6);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    gtk_signal_connect(G_OBJECT(b1), "clicked",G_CALLBACK(b1_clic_ajoutVoiture) ,entry);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceModefierVoiture(int argc, char**argv, Voiture voiture){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->argc=argc;
    entry->argv=argv;
    //*creation de la fentre:
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Modefier Voiture");
    gtk_window_set_default_size(entry->f1, 200, 200);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new("La Marque:");
    GtkWidget* l2=gtk_label_new("Nom de la Voiture:");
    GtkWidget* l3=gtk_label_new("Couleur:");
    GtkWidget* l4=gtk_label_new("Nombre de Places:");
    GtkWidget* l5=gtk_label_new("Prix par Jour:");
    GtkWidget* l6=gtk_label_new("Allouer:");
    GtkWidget* b1=gtk_button_new_with_label ("Modefier Voiture");
    entry->t1=gtk_entry_new();
    entry->t2=gtk_entry_new();
    entry->t3=gtk_entry_new();
    entry->t4=gtk_entry_new();
    entry->t5=gtk_entry_new();
    entry->t6=gtk_entry_new();
    entry->idVoiture=voiture.idVoiture;
    gtk_entry_set_text(entry->t1, (gchar*)voiture.marque);
    gtk_entry_set_text(entry->t2, (gchar*)voiture.nomVoiture);
    gtk_entry_set_text(entry->t3, (gchar*)voiture.couleur);
    char str[20];
    sprintf(str,"%d",voiture.nbplaces);
    gtk_entry_set_text(entry->t4, (gchar*)str);
    sprintf(str,"%d",voiture.prixJour);
    gtk_entry_set_text(entry->t5, (gchar*)str);
    gtk_entry_set_text(entry->t6, (gchar*)voiture.EnLocation);
    GtkWidget* p1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p2=gtk_hbox_new(TRUE, 0);
    GtkWidget* p3=gtk_hbox_new(TRUE, 0);
    GtkWidget* p4=gtk_hbox_new(TRUE, 0);
    GtkWidget* p5=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6=gtk_hbox_new(TRUE, 0);
    GtkWidget* p6_1=gtk_hbox_new(TRUE, 0);
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p1), l1); gtk_container_add(GTK_CONTAINER(p1), entry->t1);
    gtk_container_add(GTK_CONTAINER(p2), l2); gtk_container_add(GTK_CONTAINER(p2), entry->t2);
    gtk_container_add(GTK_CONTAINER(p3), l3); gtk_container_add(GTK_CONTAINER(p3), entry->t3);
    gtk_container_add(GTK_CONTAINER(p4), l4); gtk_container_add(GTK_CONTAINER(p4), entry->t4);
    gtk_container_add(GTK_CONTAINER(p5), l5); gtk_container_add(GTK_CONTAINER(p5), entry->t5);
    gtk_container_add(GTK_CONTAINER(p6_1), l6); gtk_container_add(GTK_CONTAINER(p6_1), entry->t6);
    gtk_container_add(GTK_CONTAINER(p6), b1);
    gtk_container_add(GTK_CONTAINER(p7),p1);
    gtk_container_add(GTK_CONTAINER(p7),p2);
    gtk_container_add(GTK_CONTAINER(p7),p3);
    gtk_container_add(GTK_CONTAINER(p7),p4);
    gtk_container_add(GTK_CONTAINER(p7),p5);
    gtk_container_add(GTK_CONTAINER(p7),p6_1);
    gtk_container_add(GTK_CONTAINER(p7),p6);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    gtk_signal_connect(G_OBJECT(b1), "clicked",G_CALLBACK(b1_clic_ModefierVoiture) ,entry);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    //gtk_window_set_focus(entry->f1, entry->f1);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceAfficheCLient(int argc, char**argv, char* infoClient){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "La Liste des Clients");
    gtk_window_set_default_size(entry->f1, 700, 100);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    //*creation des labels
    GtkWidget* l1=gtk_label_new(infoClient);
    GtkWidget* l2=gtk_label_new("        ");
    GtkWidget* l3=gtk_label_new("        ");
    GtkWidget* l4=gtk_label_new("        ");
    GtkWidget* l5=gtk_label_new("        ");
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p7), l1);
    gtk_container_add(GTK_CONTAINER(p7), l2);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceAfficheVoiture(int argc, char**argv, char* infoVoiture){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "La Liste des Voitures");
    gtk_window_set_default_size(entry->f1, 900, 100);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    GtkWidget* l1=gtk_label_new(infoVoiture);
    GtkWidget* l2=gtk_label_new("        ");
    GtkWidget* l3=gtk_label_new("        ");
    GtkWidget* l4=gtk_label_new("        ");
    GtkWidget* l5=gtk_label_new("        ");
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p7), l1);
    gtk_container_add(GTK_CONTAINER(p7), l2);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void interfaceAfficheContrat(int argc, char**argv, char* infoContrat){
    data* entry=(data*)malloc(sizeof(data));
    gtk_init(&argc, &argv);
    entry->f1=NULL;
    entry->f1=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(entry->f1), "Visualisation du Contrat:");
    gtk_window_set_default_size(entry->f1, 500, 100);
    gtk_window_set_position(entry->f1, GTK_WIN_POS_CENTER);
    gtk_window_set_deletable(entry->f1, TRUE);
    GtkWidget* l1=gtk_label_new(infoContrat);
    GtkWidget* l2=gtk_label_new("        ");
    GtkWidget* l3=gtk_label_new("        ");
    GtkWidget* l4=gtk_label_new("        ");
    GtkWidget* l5=gtk_label_new("        ");
    GtkWidget* p7=gtk_vbox_new(TRUE,0);
    gtk_container_add(GTK_CONTAINER(p7), l1);
    gtk_container_add(GTK_CONTAINER(p7), l2);
    gtk_container_add(GTK_CONTAINER(entry->f1), p7);
    g_signal_connect(G_OBJECT(entry->f1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(entry->f1);
    gtk_main();
}

void MenuGestionClient(int argc, char *argv[]){
    int choixMenuClient=-1;
   while(1){
    printf("                                         Gestion Client               \n");
    printf("                         Liste des Clients...........................1\n");
    printf("                         Ajouter Client..............................2\n");
    printf("                         Modefier Client.............................3\n");
    printf("                         Supprimer Client............................4\n");
    printf("                         Retour au Menu Principal....................5\n");
    printf("                                        Votre Choix: ");
    scanf("%d",&choixMenuClient);
    if(choixMenuClient==1){
        char infoClient[100000]="";
        affiche_list_client(liste_total_client, infoClient);
        interfaceAfficheCLient(argc, argv, infoClient);
    }
    else if(choixMenuClient==2)
        interfaceAjouterClient(argc, argv);
    else if(choixMenuClient==3){
            int idClient=-1;
            printf("                                        Entrez l'Identit� du Client: ");
            scanf("%d", &idClient);
            Client* client=trouverClientId(liste_total_client, idClient);
            if(client!=NULL){
                interfaceModefierClient(argc, argv, *client);
            }else{
                gtk_init(&argc, &argv);
                GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
                gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
                interfaceBoitDialog(windows, "Le client n'existe pas ou bien l'identite entre est errone");
            }

    }
    else if(choixMenuClient==4){
            gtk_init(&argc, &argv);
            GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
            gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
            int idClient=-1;
            printf("                                        Entrez l'Identit� du Client: ");
            scanf("%d", &idClient);
            int etat=supprimer_Client_List(idClient, &liste_total_client);
            if(etat==1)
                interfaceBoitDialog(windows, "Le client a ete supprimer avec succes");
            else if (etat==0)
                interfaceBoitDialog(windows, "Le client n'existe pas ou bien l'identite entre est errone");
    }
    else if(choixMenuClient==5)
        return;
   }
}

void MenuGestionVoiture(int argc, char *argv[]){
    int choixMenuVoiture=-1;
   while(1){
    printf("                                        Gestion Voiture               \n");
    printf("                         Liste des Voitures...........................1\n");
    printf("                         Ajouter Voiture..............................2\n");
    printf("                         Modefier Voiture.............................3\n");
    printf("                         Supprimer Voiture............................4\n");
    printf("                         Retour au Menu Principal.....................5\n");
    printf("                                        Votre Choix: ");
    scanf("%d",&choixMenuVoiture);
    if(choixMenuVoiture==1){
        char infoVoiture[100000]="";
        affiche_list_voiture(liste_total_voiture, infoVoiture);
        interfaceAfficheVoiture(argc, argv, infoVoiture);
    }
    else if(choixMenuVoiture==2)
            interfaceAjouterVoiture(argc, argv);
    else if(choixMenuVoiture==3){
            int idVOiture=-1;
            printf("                                        Entrez l'Identit� de la Voiture: ");
            scanf("%d", &idVOiture);
            Voiture* voiture=trovuerVoitureId(liste_total_voiture, idVOiture);
            if(voiture!=NULL){
                interfaceModefierVoiture(argc, argv, *voiture);
            }else{
                gtk_init(&argc, &argv);
                GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
                gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
                interfaceBoitDialog(windows, "La Voiture n'existe pas ou bien l'identite entre est errone");
            }

    }
    else if(choixMenuVoiture==4){
            gtk_init(&argc, &argv);
            GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
            gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
            int idVoiture=-1;
            printf("                                        Entrez l'Identit� du Voiture: ");
            scanf("%d", &idVoiture);
            int etat=supprimer_Voiture_List(idVoiture, &liste_total_voiture);
            if(etat==1)
                interfaceBoitDialog(windows, "La voiture a ete supprimer avec succes");
            else if (etat==0)
                interfaceBoitDialog(windows, "La voiture n'existe pas ou bien l'identite entre est errone");
    }
    else if(choixMenuVoiture==5)
        return;
   }
}

void MenuGestionLocation(int argc, char *argv[]){
    int choixMenuLocation=-1;
   while(1){
    printf("                                        Location d'une Voiture         \n");
    printf("                         Visualiser Contrat...........................1\n");
    printf("                         Louer Voiture................................2\n");
    printf("                         Retourner Voiture............................3\n");
    printf("                         Modefier Contrat.............................4\n");
    printf("                         Supprimer Contrat............................5\n");
    printf("                         Retour au Menu Principal.....................6\n");
    printf("                                        Votre Choix: ");
    scanf("%d",&choixMenuLocation);
    if(choixMenuLocation==1){
        int idContrat=-1;
        printf("                                        Entrez l'Identit� du Contrat d'Allocation a Visualiser: ");
        scanf("%d", &idContrat);
        char infoContrat[100000]="";
        int etat=affiche_contrat_location(idContrat, liste_contrats, infoContrat);
        if(etat==1)
            interfaceAfficheContrat(argc, argv, infoContrat);
        else{
            gtk_init(&argc, &argv);
            GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
            gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
            interfaceBoitDialog(windows, "Le contrat n'existe pas ou bien l'identite entre est errone");
        }
   }
    else if(choixMenuLocation==2)
        interfaceAllouerVoiture(argc, argv);
    else if(choixMenuLocation==3){
            gtk_init(&argc, &argv);
            GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
            gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
            int idContrat=-1;
            printf("                                        Entrez l'Identit� du Contrat d'Allocation: ");
            scanf("%d", &idContrat);
            int etat=retourner_voiture_louer(idContrat, &liste_contrats);
            if(etat==1)
                interfaceBoitDialog(windows, "La voiture a ete retouner avec succes");
            else if (etat==0)
                interfaceBoitDialog(windows, "Le contrat n'existe pas ou bien l'identite entre est errone");
    }
    else if(choixMenuLocation==4){
            int numContrat=-1;
            printf("                                        Entrez l'Identit� du Contrat d'Allocatin: ");
            scanf("%d", &numContrat);
            ContratLocation* contrat=trouverContratId(liste_contrats, numContrat);
            if(contrat!=NULL){
                    Client* client=trouverClientId(liste_total_client, contrat->idClient);
                    Voiture* voiture=trovuerVoitureId(liste_total_voiture, contrat->idVoiture);
                    interfaceModefAllouerVoiture(argc, argv, *client, *voiture, *contrat);
            }else{
                gtk_init(&argc, &argv);
                GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
                gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
                interfaceBoitDialog(windows, "Le contrat d'allocation n'existe pas ou bien l'identite entre est errone");
            }
    }
    else if(choixMenuLocation==5){
            gtk_init(&argc, &argv);
            GtkWidget* windows=gtk_window_new(GTK_WINDOW_TOPLEVEL);
            gtk_window_set_position(windows, GTK_WIN_POS_CENTER);
            int idContrat=-1;
            printf("                                        Entrez l'Identit� du Contrat d'Allocation: ");
            scanf("%d", &idContrat);
            int etat=supprimer_contrat_location_List(idContrat, &liste_contrats);
            if(etat==1)
                interfaceBoitDialog(windows, "Le contrat a ete supprimer avec succes");
            else if (etat==0)
                interfaceBoitDialog(windows, "Le contrat n'existe pas ou bien l'identite entre est errone");
    }
    else if(choixMenuLocation==6)
        return;
   }
}

void MenuGestionLocationVoiture(int argc, char *argv[]){
    init_contrat(&liste_contrats);
   int choixMenuPrincipal=-1;
   while(1){
    printf("                                        Menu Principal               \n");
    printf("                         Location...................................1\n");
    printf("                         Gestion Voitures...........................2\n");
    printf("                         Gestion Clients............................3\n");
    printf("                         Quitter....................................4\n");
    printf("                                        Votre Choix: ");
    scanf("%d",&choixMenuPrincipal);
    if(choixMenuPrincipal==1)
        MenuGestionLocation(argc, argv);
    else if(choixMenuPrincipal==2)
        MenuGestionVoiture(argc, argv);
    else if(choixMenuPrincipal==3)
        MenuGestionClient(argc, argv);
    else if(choixMenuPrincipal==4){
            exit_contrat(liste_contrats, &afficheContratArbre);
            exit(1);
    }
   }
}

#endif // LOCATION_H_INCLUDED
