#ifndef DATE_H_INCLUDED
#define DATE_H_INCLUDED
#include<stdio.h>

typedef struct Date{
    int jour;
    char mois[10];
    int moisN;
    int nbrJour;
    int annee;
}Date;

void mois_moisN(Date* date){
    if(!strcmp(date->mois,"Janvier")){
        date->moisN=1;
        date->nbrJour=31;
        }
    if(!strcmp(date->mois,"Fevrier")){
        date->moisN=2;
        date->nbrJour=28;
        }
    if(!strcmp(date->mois,"Mars")){
        date->moisN=3;
        date->nbrJour=31;
        }
    if(!strcmp(date->mois,"Avril")){
        date->moisN=4;
        date->nbrJour=30;
        }
    if(!strcmp(date->mois,"Mai")){
        date->moisN=5;
        date->nbrJour=31;
        }
    if(!strcmp(date->mois,"Juin")){
        date->moisN=6;
        date->nbrJour=30;
        }
    if(!strcmp(date->mois,"Juillet")){
        date->moisN=7;
        date->nbrJour=31;
        }
    if(!strcmp(date->mois,"Aout")){
        date->moisN=8;
        date->nbrJour=31;
        }
    if(!strcmp(date->mois,"Septembre")){
        date->moisN=9;
        date->nbrJour=30;
        }
    if(!strcmp(date->mois,"Octobre")){
        date->moisN=10;
        date->nbrJour=31;
        }
    if(!strcmp(date->mois,"Novembre")){
        date->moisN=11;
        date->nbrJour=30;
        }
    if(!strcmp(date->mois,"Decembre")){
        date->moisN=12;
        date->nbrJour=31;
        }
}

void datecpy(Date* dest, Date* src){
    dest->annee=src->annee;
    dest->jour=src->jour;
    dest->moisN=src->moisN;
    dest->nbrJour=src->nbrJour;
    strcpy(dest->mois, src->mois);
}

void affiche_date(Date date){
    printf("Jour: %d  S_Mois: %s  annee: %d  N_Mois: %d Nombre_Jour: %d\n",date.jour, date.mois, date.annee, date.moisN, date.nbrJour);
}
#endif // DATE_H_INCLUDED
